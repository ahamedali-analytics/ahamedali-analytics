<div align="center">

<img src="assets/hero.svg" alt="Ahamed Ali - animated hero" width="100%"/>

</div>

## 🛠️ What I build

I turn raw data into dashboards, reports, and decisions. *(Edit this paragraph — 2–3 lines about your work.)*

- 📊 Interactive dashboards and KPI reporting
- 🧹 Data cleaning and analysis with SQL and Python
- 📈 Turning numbers into stories stakeholders can act on

<div align="center">
<img src="assets/hobbies.svg" alt="Hobbies carousel" width="100%"/>
</div>

<div align="center">
<img src="assets/orbit.svg" alt="Tech stack orbit" width="100%"/>
</div>

<div align="center">
<img src="assets/badge.svg" alt="ID badge and dashboard" width="100%"/>
</div>

## 📁 Projects

| Project | What it does | Stack |
|---|---|---|
| [Project one](https://github.com/ahamedali-analytics) | One-line description | Python · SQL |
| [Project two](https://github.com/ahamedali-analytics) | One-line description | Power BI |
| [Project three](https://github.com/ahamedali-analytics) | One-line description | Excel · Tableau |

<div align="center">
<img src="assets/city.svg" alt="Contribution city" width="100%"/>
</div>

<div align="center">
<img src="assets/footer.svg" alt="Connect with me" width="100%"/>
</div>
